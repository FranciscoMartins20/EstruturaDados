public class FP7_EX2 {
    public static void main(String[] args) {
        // Os métodos tem que ser criados na double linked list
    }
}
