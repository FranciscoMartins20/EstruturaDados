package Data_Structure;

public class EmptyCollectionException extends Throwable {
    public EmptyCollectionException(String message) {
        super(message);
    }
}
